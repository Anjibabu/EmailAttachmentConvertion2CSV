﻿using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Threading;
using Quartz;
using Schedule.Core;

namespace Schedule.Single
{
    public class TestScheduleContext : ScheduleContext
    {
        private TestSchedule _testSchedule;

        public TestSchedule TestSchedule
        {
            get
            {
                _testSchedule = _testSchedule ?? new TestSchedule(Scheduler);
                return _testSchedule;
            }
        }

        public TestScheduleContext()
        {
            Props = new NameValueCollection
            {
                //{"quartz.scheduler.interruptJobsOnShutdownWithWait", "true"},
                {"quartz.scheduler.instanceName", nameof(TestScheduleContext)}
            };
            Start();
        }
    }
}
