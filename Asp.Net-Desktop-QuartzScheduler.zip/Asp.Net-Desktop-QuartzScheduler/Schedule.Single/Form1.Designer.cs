﻿namespace Schedule.Single
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.chkBoxStartEnd = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.AcceptsTab = true;
            this.richTextBox1.Location = new System.Drawing.Point(12, 46);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(860, 436);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // chkBoxStartEnd
            // 
            this.chkBoxStartEnd.AutoSize = true;
            this.chkBoxStartEnd.Location = new System.Drawing.Point(12, 12);
            this.chkBoxStartEnd.Name = "chkBoxStartEnd";
            this.chkBoxStartEnd.Size = new System.Drawing.Size(83, 17);
            this.chkBoxStartEnd.TabIndex = 2;
            this.chkBoxStartEnd.Text = "Start/Pause";
            this.chkBoxStartEnd.UseVisualStyleBackColor = true;
            this.chkBoxStartEnd.Click += new System.EventHandler(this.chkBoxStartEnd_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 494);
            this.Controls.Add(this.chkBoxStartEnd);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Form1";
            this.Text = "Sched Test";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.CheckBox chkBoxStartEnd;
    }
}

