﻿using System;
using System.ComponentModel;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Net.Mail;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Outlook;
using Schedule.Ui.Core;
using excel = Microsoft.Office.Interop.Excel;
namespace Schedule.Single
{
    public partial class Form1 : Form
    {
        private const uint MaxLine = 720;
        private const string DateTimeDisplayFormat = "dd-MMM-yyyy hh:mm:ss tt";
        private DateTime _lastEstimatedStartTime;

        private readonly BackgroundWorker Bw;
        private TestScheduleContext _scheduleContext;

        public Form1()
        {
            InitializeComponent();

            Bw = new BackgroundWorker();
            Bw.WorkerSupportsCancellation = true;
            Bw.DoWork += StartScheduler;
            Bw.RunWorkerCompleted += BgWorkerCompleted;
            Bw.RunWorkerAsync();
        }

        private void StartSchedule()
        {
            if (!_scheduleContext.TestSchedule.IsStarted())
            {
                _scheduleContext.TestSchedule.TaskStarted += BeforeStart;
                _scheduleContext.TestSchedule.TaskVetoed += Vetoed;
                _scheduleContext.TestSchedule.TaskExecuted += AfterEnd;
                _scheduleContext.TestSchedule.TaskShouldBeVetoed += TaskShouldBeVetoed;
                _scheduleContext.TestSchedule.Start();
            }
            else
            {
                _scheduleContext.TestSchedule.Resume();
            }
            PrintNextEstimatedStartTime(_scheduleContext.TestSchedule.NextEstimatedFireTime());
        }

        private bool TaskShouldBeVetoed()
        {
            var value = DateTime.Now.ToString(DateTimeDisplayFormat) != _lastEstimatedStartTime.ToString(DateTimeDisplayFormat);
            return value;
        }

        private void Vetoed()
        {
            string dateTime = DateTime.Now.ToString(DateTimeDisplayFormat);
            this.Invoke((MethodInvoker)delegate
            {
                richTextBox1.AppendText("\t\t" + "Vetoed: " + dateTime);
                richTextBox1.ScrollToCaret();
            });
            PrintNextEstimatedStartTime(_scheduleContext.TestSchedule.NextEstimatedFireTime());
        }

        private void PausedSchedule()
        {
            _scheduleContext.TestSchedule.Pause();
            if (_scheduleContext.TestSchedule.IsTaskRunning())
            {
                MessageBox.Show("Task still running, will be paused after task ends.");
                return;
            }

            this.Invoke((MethodInvoker)delegate
            {
                richTextBox1.AddLine("Paused", MaxLine);
                richTextBox1.ScrollToCaret();
            });
        }

        private void StartScheduler(object sender, DoWorkEventArgs e)
        {
            /*close backgraound worker*/
            if (Bw.CancellationPending)
            {
                e.Cancel = true;
                return;
            }

            /*schedule*/
            _scheduleContext = new TestScheduleContext();

            /*control*/
            this.Invoke((MethodInvoker)delegate
            {
                chkBoxStartEnd.Appearance = Appearance.Button;
                chkBoxStartEnd.TextAlign = ContentAlignment.MiddleCenter;
                chkBoxStartEnd.MinimumSize = new Size(75, 25); //To prevent shrinkage!
                chkBoxStartEnd.Text = "Start";
            });
        }

        private void BgWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                Log.WriteError("SchedulerTest", e.Error);

                this.Invoke((MethodInvoker)delegate
                {
                    richTextBox1.AddLine("Error to Run!");
                    richTextBox1.ScrollToCaret();
                });
            }
        }

        private void PrintNextEstimatedStartTime(DateTime? dateTime)
        {
            string msg = "Estimated: ";
            if (dateTime != null)
            {
                _lastEstimatedStartTime = ((DateTime) dateTime);
                msg += _lastEstimatedStartTime.ToString(DateTimeDisplayFormat);
            }

            this.Invoke((MethodInvoker)delegate
            {
                richTextBox1.AddLine(msg, MaxLine);
                richTextBox1.ScrollToCaret();
            });
        }

        private void BeforeStart()
        {
            string startDateTime = DateTime.Now.ToString(DateTimeDisplayFormat);
            this.Invoke((MethodInvoker)delegate
            {
                richTextBox1.AppendText("\t\t" + "Started: " + startDateTime);
                richTextBox1.ScrollToCaret();
            });
            EmailReadFromOutLook();
        }

        private void AfterEnd(System.Exception exception)
        {
            this.Invoke((MethodInvoker)delegate
            {
                richTextBox1.AppendText("\t\t" + "Ended: " + DateTime.Now.ToString(DateTimeDisplayFormat));
                richTextBox1.ScrollToCaret();
            });
            string status = String.Empty;
            if (exception != null)
            {
                status = "Error";
                Log.WriteError("SchedulerTest", exception);
            }
            else
            {
                status = "Success";
            }
            this.Invoke((MethodInvoker)delegate
            {
                richTextBox1.AppendText("\t\t" + "Result: " + status);
                richTextBox1.ScrollToCaret();
            });

            if (_scheduleContext.TestSchedule.IsPaused())
            {
                this.Invoke((MethodInvoker)delegate
                {
                    richTextBox1.AddLine("Paused", MaxLine);
                    richTextBox1.ScrollToCaret();
                });
            }
            else
            {
                PrintNextEstimatedStartTime(_scheduleContext.TestSchedule.NextEstimatedFireTime());
            }
        }

        private void chkBoxStartEnd_Click(object sender, EventArgs e)
        {
            if (chkBoxStartEnd.Checked)
            {
                StartSchedule();
                
                chkBoxStartEnd.Text = "Pause";
            }
            else
            {
                PausedSchedule();
                chkBoxStartEnd.Text = "Start";
            }
        }
        private   Workbook mWorkBook;
        private   Sheets mWorkSheets;
        private   Worksheet mWSheet1;
        private   Microsoft.Office.Interop.Excel.Application oXL;
        private   string ErrorMessage = string.Empty;

        public static string BasePath
        {
            get
            {
                return ConfigurationManager.AppSettings["folderPath"];
            }
        }
        private   void EmailReadFromOutLook()
        {
            this.Invoke((MethodInvoker)delegate
            {
                richTextBox1.AddLine("Email Reading..", MaxLine);
                richTextBox1.ScrollToCaret();
            });
            Console.WriteLine("Running.." + DateTime.Now.ToShortDateString() + "--" + DateTime.Now.ToLongTimeString());
            Microsoft.Office.Interop.Outlook.Application outlookApplication = null;
            NameSpace outlookNamespace = null;
            MAPIFolder inboxFolder = null;
            Items mailItems = null;
            try
            {
                outlookApplication = new Microsoft.Office.Interop.Outlook.Application();
                outlookNamespace = outlookApplication.GetNamespace("MAPI");
                inboxFolder = outlookNamespace.GetDefaultFolder(OlDefaultFolders.olFolderInbox);
                mailItems = inboxFolder.Items;
                string Filter = "[ReceivedTime] >= Today";

                Items mis = inboxFolder.Items.Restrict(Filter);
                int cnt = mis.Count; ;

                //DeleteAllFiles();
                foreach (MailItem item in mis)
                {
                    if (item.Attachments.Count > 0)
                    {
                        foreach (Microsoft.Office.Interop.Outlook.Attachment attach in item.Attachments)
                        {
                            SaveFile(attach);
                        }
                    }
                    Marshal.ReleaseComObject(item);
                }
            }
            //Error handler.
            catch (System.Exception e)
            {
                Console.WriteLine(string.Format("{0} Exception caught: {0} ", e));
            }
            finally
            {
                ReleaseComObject(mailItems);
                ReleaseComObject(inboxFolder);
                ReleaseComObject(outlookNamespace);
                ReleaseComObject(outlookApplication);
            }
            Console.WriteLine("Done");
            Console.ReadLine();
        }

        public   void DeleteAllFiles()
        {
            System.IO.DirectoryInfo di = new DirectoryInfo(BasePath);

            foreach (FileInfo file in di.GetFiles())
            {
                file.Delete();
            }
        }

        public   void SaveAsCSV(string sourcePath)
        {
            excel.Application xlApp = new excel.Application();
            excel.Workbook xlWorkBook = xlApp.Workbooks.Open(sourcePath);
            xlApp.Visible = false;
            foreach (excel.Worksheet sht in xlWorkBook.Worksheets)
            {
                sht.Select();
                string currentFileName = Path.GetFileNameWithoutExtension(sourcePath);
                string csvFilePath = string.Format("{0}.csv", Path.Combine(BasePath, currentFileName));
                if (File.Exists(csvFilePath))
                {
                    File.Delete(csvFilePath);
                }
                xlWorkBook.SaveAs(csvFilePath, excel.XlFileFormat.xlCSV, excel.XlSaveAsAccessMode.xlNoChange);

            }
            xlWorkBook.Close(false);
            xlApp.Quit();
        }
        public   void SaveFile(Microsoft.Office.Interop.Outlook.Attachment attach)
        {
            var fileName = BasePath + attach.FileName;
            string fileExtension = Path.GetExtension(fileName);
            string filenameWithNameWithExtension = Path.GetFileName(fileName);
            string xlxFilePath = Path.Combine(BasePath, filenameWithNameWithExtension);
            if (fileExtension == ".xls" || fileExtension == ".xlsx")
            {
                attach.SaveAsFile(xlxFilePath);
                SaveAsCSV(xlxFilePath);
                if (File.Exists(xlxFilePath))
                {
                    File.Delete(xlxFilePath);
                }
            }
            else
            {
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }
                attach.SaveAsFile(fileName);
            }
        }
        private   void ReleaseComObject(object obj)
        {
            if (obj != null)
            {
                Marshal.ReleaseComObject(obj);
                obj = null;
            }
        }
        private void CloseApp()
        {
            /*stop shedule*/
            _scheduleContext.Stop();

            /*close backgraound worker
             *https://stackoverflow.com/questions/4732737/how-to-stop-backgroundworker-correctly
             */
            if (Bw.IsBusy)
            {
                Bw.CancelAsync();
            }
            while (Bw.IsBusy)
            {
                System.Windows.Forms.Application.DoEvents();
            }

            /*kill all running process
             * https://stackoverflow.com/questions/8507978/exiting-a-c-sharp-winforms-application
             */
            System.Diagnostics.Process.GetCurrentProcess().Kill();
            System.Windows.Forms.Application.Exit();
            Environment.Exit(0);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_scheduleContext.TestSchedule.IsTaskRunning())
            {
                var window = MessageBox.Show(
                    "A task is in progress, do you still want to close?",
                    "Close Window",
                    MessageBoxButtons.YesNo);
                if (window == DialogResult.Yes)
                {
                    CloseApp();
                }
                e.Cancel = (window == DialogResult.No);
            }
            else
            {
                CloseApp();
            }
        }
    }
}
