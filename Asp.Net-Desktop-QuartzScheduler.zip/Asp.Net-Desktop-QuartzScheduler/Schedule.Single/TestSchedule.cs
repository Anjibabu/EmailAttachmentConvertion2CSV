﻿using System;
using System.Configuration;
using System.Threading;
using Quartz;

namespace Schedule.Single
{
    [PersistJobDataAfterExecution]      /*save temp data*/
    [DisallowConcurrentExecution]       /*impt: no multiple instances executed concurrently*/
    public class TestScheduleJob : IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            int count = 0;
            try
            {
                JobDataMap jobData = context.JobDetail.JobDataMap;
                count = Convert.ToInt32(jobData["Count"]);
                jobData["Count"] = ++count;
            }
            catch
            {
            }

            int jobDuration = Convert.ToInt32(ConfigurationManager.AppSettings["JobDurationMilliseconds"]);
            jobDuration = count % 2 == 0 ? jobDuration : 2 * jobDuration;
            Thread.Sleep(jobDuration);
        }
    }

    public class TestSchedule : Schedule.Core.Schedule
    {
        public TestSchedule(IScheduler scheduler) : base(scheduler, "TestSchedule")
        {
        }

        protected override Tuple<JobBuilder, TriggerBuilder> Settings()
        {
            string cronJobExpression = ConfigurationManager.AppSettings["CronJobExpression"];
            TriggerBuilder triggerBuilder = TriggerBuilder.Create().WithCronSchedule(cronJobExpression);
            JobBuilder jobBuilder = JobBuilder.Create<TestScheduleJob>();
            return new Tuple<JobBuilder, TriggerBuilder>(jobBuilder, triggerBuilder);
        }
    }
}
