﻿using System;

namespace Schedule.Core
{
    public delegate void TaskExecution();
    public delegate void TaskExecutionComplete(Exception exception);

    public delegate bool ShouldTaskExecution();
}
