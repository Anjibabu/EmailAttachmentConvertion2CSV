﻿using System;
using System.Configuration;
using System.IO;

namespace Schedule.Ui.Core
{
    public class Log
    {
        public static readonly string LogDirectory;

        static Log()
        {
            LogDirectory = ConfigurationManager.AppSettings["ErrorLogDirectory"];
        }

        /*Log.WriteErrorLog("Error", ex.ToString(), "MyGpDashboardController > GetCesChartData");*/
        public static string WriteError(string errorType, Exception exception, string methodName = "")
        {
            if (!Directory.Exists(LogDirectory))
            {
                Directory.CreateDirectory(LogDirectory);
            }

            string fileName = string.Format("{0}_{1}.txt", DateTime.Now.ToString("dd-MMM-yyyy"), errorType);
            string path = LogDirectory + "\\" + fileName;       
            using (StreamWriter sw = (File.Exists(path)) ? File.AppendText(path) : File.CreateText(path))
            {
                sw.WriteLine("{0} ::::  DateTime: {1} :::: Message: {2} :::: Method Name:  {3}", errorType, DateTime.Now.ToString(), exception.ToString(), methodName);
                sw.WriteLine("==============================================================================================================================");
            }

            return path;
        }
    }
}